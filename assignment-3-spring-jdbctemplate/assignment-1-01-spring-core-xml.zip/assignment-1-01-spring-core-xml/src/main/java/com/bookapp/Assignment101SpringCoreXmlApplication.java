package com.bookapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment101SpringCoreXmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment101SpringCoreXmlApplication.class, args);
	}

}
